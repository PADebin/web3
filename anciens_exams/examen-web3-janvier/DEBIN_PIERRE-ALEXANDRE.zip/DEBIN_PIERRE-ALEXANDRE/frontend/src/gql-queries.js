import { gql } from "@apollo/client";

const ALL_WORDS = gql`
  query {
    words {
      id
      word
      hint1
      hint2
      hint3
    }
  }
`

const ADD_WORD = gql`
  mutation AddWord(
    $word: String!
    $hint1: String!
    $hint2: String!
    $hint3: String!
  ) {
    addWord(word: $word, hint1: $hint1, hint2: $hint2, hint3: $hint3) {
      id
      word
      hint1
      hint2
      hint3
    }
  }
`

export { ALL_WORDS, ADD_WORD };
