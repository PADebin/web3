import Footer from "components/Footer/Footer";
import Header from "components/Header/Header";
import NavBar from "components/Navbar/Navbar";
import { Outlet } from "react-router-dom";
import "./App.css";
import { useState } from "react";
//import { ALL_WORDS } from "../../gql-queries";

/*
const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: "http://localhost:4000",
  }),
});
*/

const defaultWords = [
  { id: 1, word: "wow", hint1: "amazing", hint2: "sound", hint3: "3 letters" },
];

const App = () => {
  //const defaultWords = useQuery(ALL_WORDS);
  const [words] = useState(defaultWords);
  const [errorCount, setErrorCount] = useState(0);

  const onWordGuessed = (randomWord, wordGuessed) => {
    console.log("randomWord", randomWord);
    console.log("word", wordGuessed); // Undefined
    if (wordGuessed === randomWord.word) {
      console.log("You guessed the word!");
    } else {
      setErrorCount(errorCount + 1);
      console.log("You did not guess the word!");
    }
  };

  const wordContext = {
    words,
    errorCount,
    onWordGuessed,
  };

  return (
      <div className="page">
        <Header>
          <h1>Amazing Guess A Word Game</h1>
          <NavBar />
        </Header>

        <main>
          <Outlet context={wordContext} />
        </main>

        <Footer>
          <p>© Made by the Vinci team</p>
        </Footer>
      </div>
  );
};

export default App;
