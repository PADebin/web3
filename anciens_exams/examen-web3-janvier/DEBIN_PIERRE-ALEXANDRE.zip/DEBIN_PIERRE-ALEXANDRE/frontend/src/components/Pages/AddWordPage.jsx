import { useOutletContext } from "react-router-dom";
import AddWordForm from "components/AddWordForm/AddWordForm";
import PageTitle from "components/PageTitle/PageTitle";

const AddWordPage = () => {
  const { onWordAdded } = useOutletContext();
  return (
    <>
      <PageTitle title="Add a word" />
      <AddWordForm onWordAdded={onWordAdded} />
    </>
  );
};

export default AddWordPage;