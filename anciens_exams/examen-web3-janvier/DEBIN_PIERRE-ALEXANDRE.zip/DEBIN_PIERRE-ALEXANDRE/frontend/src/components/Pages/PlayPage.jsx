import { useOutletContext } from "react-router-dom";
import PageTitle from "components/PageTitle/PageTitle";
import GuessWordForm from "components/GuessWordForm/GuessWordForm";

const PlayPage = () => {
  const { onWordGuessed } = useOutletContext();
  return (
        <>
          <PageTitle title="Play" />
          <h2>Welcome to the `guess a word` game</h2>
          <GuessWordForm onWordGuessed={onWordGuessed} />
        </>
  );
};

export default PlayPage;