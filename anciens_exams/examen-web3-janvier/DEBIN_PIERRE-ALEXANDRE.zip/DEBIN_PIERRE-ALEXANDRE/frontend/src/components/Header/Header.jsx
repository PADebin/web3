import "./Header.css";
import PropTypes from 'prop-types';

const Header = ({children}) => {
  return (
    <header className="header">
      <div>{children}</div>
    </header>
  );
};
Header.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Header;
