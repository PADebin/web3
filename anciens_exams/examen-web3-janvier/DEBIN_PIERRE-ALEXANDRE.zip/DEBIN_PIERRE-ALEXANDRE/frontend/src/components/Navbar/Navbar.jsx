import { Link } from "react-router-dom";

const NavBar = () => (
  <nav className="navbar">
    <Link to="/">Play</Link>
    <br />
    <Link to="/add-word">Add a word</Link>
  </nav>
);

export default NavBar;
