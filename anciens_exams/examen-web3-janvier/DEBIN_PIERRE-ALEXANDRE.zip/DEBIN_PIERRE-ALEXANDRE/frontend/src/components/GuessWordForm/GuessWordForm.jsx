import { useState } from "react";
import PropTypes from "prop-types";
import { useOutletContext } from "react-router-dom";

const GuessWordForm = ({ onWordGuessed }) => {
  const { words, errorCount } = useOutletContext();
  const [word, setWord] = useState("");

  //get random word from the list
  let randomWord = words[Math.floor(Math.random() * words.length)];

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("word", word); // not undefined
    onWordGuessed({ randomWord, wordGuessed: word });
    setWord("");
  };

  return (
    <div>
      <h2>Error count: {errorCount} </h2>
      <div>
        <p> Hints:</p>
        <p>Hint N°1: {randomWord.hint1} </p>
        {errorCount >= 1 && <p> Hint N°2: {randomWord.hint2} </p>}
        {errorCount >= 2 && <p> Hint N°3: {randomWord.hint3} </p>}
      </div>

      <form onSubmit={handleSubmit}>
        <div>
          <label>Guess the word :</label>
          <input
            type="text"
            value={word}
            onChange={(e) => setWord(e.target.value)}
            required
          />
        </div>
        <button type="submit">Guess</button>
      </form>
    </div>
  );
};

GuessWordForm.propTypes = {
  onWordGuessed: PropTypes.func.isRequired,
};

export default GuessWordForm;
