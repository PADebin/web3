import { useState } from "react";
import PropTypes from "prop-types";
import "./AddWordForm.css";
import { useMutation } from "@apollo/client";
import { ADD_WORD } from "../../gql-queries";

const AddWordForm = (props) => {
  const [word, setWord] = useState("");
  const [hint1, setHint1] = useState("");
  const [hint2, setHint2] = useState("");
  const [hint3, setHint3] = useState("");
  const [successfullyAdded, setSuccessfullyAdded] = useState(false);

  const [addWord] = useMutation(ADD_WORD);

  // eslint-disable-next-line react/prop-types
  if(!props.show){
    return null;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    addWord({ variables: { word, hint1, hint2, hint3 } });

    setSuccessfullyAdded(true);
    setTimeout(() => {
      setSuccessfullyAdded(false);
    }, 3000);

    setWord("");
    setHint1("");
    setHint2("");
    setHint3("");
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Word :</label>
          <input
            type="text"
            value={word}
            onChange={(e) => setWord(e.target.value)}
            required
          />
        </div>
        <br />
        <div>
          <label>Hints :</label>
          <input
            type="text"
            value={hint1}
            onChange={(e) => setHint1(e.target.value)}
            required
          />
          <br />
          <input
            type="text"
            value={hint2}
            onChange={(e) => setHint2(e.target.value)}
            required
          />
          <br />
          <input
            type="text"
            value={hint3}
            onChange={(e) => setHint3(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Word</button>
      </form>
      {successfullyAdded && <p className="success">Word added successfully</p>}
    </div>
  );
};

AddWordForm.propTypes = {
  onWordAdded: PropTypes.func.isRequired,
};

export default AddWordForm;
