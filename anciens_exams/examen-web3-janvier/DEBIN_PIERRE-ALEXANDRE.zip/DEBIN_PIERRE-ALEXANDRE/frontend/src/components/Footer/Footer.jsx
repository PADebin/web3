import "./Footer.css";
import PropTypes from 'prop-types';

const Footer = ({ children }) => {
  return (
    <footer className="footer">
      <div>{children}</div>
    </footer>
  );
};
Footer.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Footer;
