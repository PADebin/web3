import { ApolloServer } from "@apollo/server";
import { startStandaloneServer } from "@apollo/server/standalone";

const Words = [
  { id: 1, word: "wow", hint1: "amazing", hint2: "sound", hint3: "3 letters" },
];

// A schema is a collection of type definitions (hence "typeDefs")
// that together define the "shape" of queries that are executed against
// your data.
const typeDefs = `#graphql
  # Comments in GraphQL strings (such as this one) start with the hash (#) symbol.

  type Word {
    id: Int
    word: String
    hint1: String
    hint2: String
    hint3: String
  }

  # The "Query" type is special: it lists all of the available queries that
  # clients can execute, along with the return type for each. In this
  # case, the "books" query returns an array of zero or more Books (defined above).
  type Query {
    words: [Word]
    wordCount: Int!
  }

  type Mutation {
    addWord(
      word: String!, 
      hint1: String!, 
      hint2: String!, 
      hint3: String!): Word
  }
`;

// Resolvers define the technique for fetching the types defined in the
// schema. This resolver retrieves books from the "books" array above.
const resolvers = {
  Query: {
    words: () => Words,
    wordCount: () => Words.length,
  },
  Mutation: {
    addWord: (root, args) => {
      const word = { ...args, id: Words.length + 1 };
      Words.push(word);
      return word;
    },
  },
};

// The ApolloServer constructor requires two parameters: your schema
// definition and your set of resolvers.
const server = new ApolloServer({
  typeDefs,
  resolvers,
});

// Passing an ApolloServer instance to the `startStandaloneServer` function:
//  1. creates an Express app
//  2. installs your ApolloServer instance as middleware
//  3. prepares your app to handle incoming requests
//const { url } = await startStandaloneServer(server, { listen: { port: 4000 } });

//console.log(`🚀 Server listening at: ${url}`);

startStandaloneServer(server, {
  listen: { port: 4000 },
}).then(({ url }) => {
  console.log(`Server ready at ${url}`)
})